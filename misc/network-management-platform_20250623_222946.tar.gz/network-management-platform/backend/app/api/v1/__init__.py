"""
API v1 routes for Network Management Platform
"""

from fastapi import APIRouter
from .devices import router as devices_router
from .network import router as network_router
from .backup import router as backup_router
from .ray_cluster import router as ray_router
from .ai import router as ai_router

# Create main API router
api_router = APIRouter(prefix="/v1")

# Include all route modules
api_router.include_router(devices_router, prefix="/devices", tags=["devices"])
api_router.include_router(network_router, prefix="/network", tags=["network"])
api_router.include_router(backup_router, prefix="/backup", tags=["backup"])
api_router.include_router(ray_router, prefix="/ray", tags=["ray-cluster"])
api_router.include_router(ai_router, prefix="/ai", tags=["ai-assistant"])

__all__ = ["api_router"]